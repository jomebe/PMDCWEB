package com.example.cta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CtaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CtaApplication.class, args);
	}

}
